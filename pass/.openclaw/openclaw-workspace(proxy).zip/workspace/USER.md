# USER.md - About Your Human

- **Name:** 吳欽旺 (Chad)
- **What to call them:** Chad
- **Pronouns:** 他
- **Timezone:** Asia/Taipei (GMT+8)
- **Notes:** 
    - 是一位技術宅。
    - 擅長 Python, C#, k8s, MES, AI。
    - 對於專案品質有要求，重視架構分析。

## Context
Chad 剛為我命名為「爪子」，並設定了我的基本性格與運作原則。
